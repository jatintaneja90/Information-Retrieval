-- Crawler Task 2 --
created in python 2.7
####Steps to install this Page_Rank algo implementation###
1) Check whether python2.7 has been installed on your system or not.If not please install it to run this program. 
2) Copy the given folder on your desktop.
3) This folder contains 9 subfolders ,one for each deliverable
4) To run page_rank algo, go to 1-> Page_Rank_Algo
5) Here you should see 2 folders G1 and G2. 
6) To create G1 graph page rank statistics, run the code in G1 folder and if you want to create G2 graph page rank statistics, run the code in G1 folder.Code available in both folders(G1,G2) are same except that they are using different source files(directed_graph.txt and G2.txt respectively).






