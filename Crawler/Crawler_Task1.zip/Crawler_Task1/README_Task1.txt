-- Crawler Task 1 --
created in python 2.7
####Steps to install this crawler###
1) Check whether python2.7 has been installed on your system or not.If not please install it to run this program. 
2) Copy the given folder on your desktop.
3) This folder contains 4 files
crawler -> This file contain code to crawl different URLs based on given seed.
file-handler -> This file contains all the functions related to files.
parse_html -> This file contains functions to handle HTML parser.
main -> This file is the main file of program which fetches all URL.
bs4 library -> This library is an external library which is needed to parse files. (If main will not run, place this library at C:\Python27\Lib\site-packages)

Procedure to run this program
1) Right click on main folder and open it in IDLE editor.
2) Press F5 key to run the program.



